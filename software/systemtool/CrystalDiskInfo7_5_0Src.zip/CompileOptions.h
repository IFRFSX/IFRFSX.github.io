// CSMI Support
#define CSMI_SUPPORT

// Server Core Support
//#define SERVER_CORE_SUPPORT