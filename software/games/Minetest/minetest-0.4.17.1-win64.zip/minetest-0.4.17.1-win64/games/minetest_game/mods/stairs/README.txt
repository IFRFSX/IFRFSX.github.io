Minetest Game mod: stairs
=========================
See license.txt for license information.

Authors of source code
----------------------
Originally by Kahrl <kahrl@gmx.net> (LGPL 2.1) and
celeron55, Perttu Ahola <celeron55@gmail.com> (LGPL 2.1)
Various Minetest developers and contributors (LGPL 2.1)

Authors of media (models)
-------------------------
Jean-Patrick G. (kilbith) <jeanpatrick.guerrero@gmail.com> (CC BY-SA 3.0):
  stairs_stair.obj


